# 📚 Student Management System

> **A full-stack, production-style CRUD web application built with Django REST Framework + Vanilla JS SPA**
>
> **Author:** SARANEESH S | V.S.B. Engineering College, Karur
> **Project Type:** Mini Web Application — College Submission

---

## 📋 Table of Contents

1. [Project Description](#1-project-description)
2. [Objectives](#2-objectives)
3. [Features](#3-features)
4. [Technology Stack](#4-technology-stack)
5. [System Architecture](#5-system-architecture)
6. [Database Design](#6-database-design)
7. [CRUD Explanation](#7-crud-explanation)
8. [API Documentation](#8-api-documentation)
9. [Security Features](#9-security-features)
10. [Installation Steps](#10-installation-steps)
11. [Environment Setup](#11-environment-setup)
12. [Database Migration & Seeding](#12-database-migration--seeding)
13. [Running the Application](#13-running-the-application)
14. [Postman API Testing](#14-postman-api-testing)
15. [Test Suite](#15-test-suite)
16. [Project Structure](#16-project-structure)
17. [Screenshots](#17-screenshots)
18. [Future Enhancements](#18-future-enhancements)
19. [Advantages](#19-advantages)
20. [Limitations](#20-limitations)
21. [Conclusion](#21-conclusion)
22. [GitHub Usage](#22-github-usage)

---

## 1. Project Description

The **Student Management System (SMS)** is a full-stack web application that enables college staff and administrators to manage student records efficiently. It provides a clean, professional dashboard interface with complete CRUD (Create, Read, Update, Delete) operations, search/filter functionality, role-based access control, and a secure REST API — all demonstrable during college viva.

The frontend is a Single-Page Application (SPA) built in pure HTML5/CSS3/JavaScript (no React build step needed) that communicates with a Django REST Framework backend over a token-authenticated REST API. The database uses SQLite for easy development and is designed for seamless migration to MySQL or PostgreSQL.

---

## 2. Objectives

- Demonstrate complete **CRUD** operations on student records
- Implement **Role-Based Access Control** (Admin vs Staff)
- Apply **secure coding practices** (password hashing, CSRF, input validation, parameterised queries)
- Build a **REST API** testable via Postman
- Create a **professional, responsive UI** matching real-world production applications
- Provide a **comprehensive automated test suite** (40 tests)

---

## 3. Features

### Core CRUD
| Feature | Admin | Staff |
|---------|-------|-------|
| View all students | ✅ | ✅ |
| View student details | ✅ | ✅ |
| Add student | ✅ | ❌ |
| Edit student | ✅ | ❌ |
| Delete student | ✅ | ❌ |
| Manage departments | ✅ | View only |
| View all users | ✅ | ❌ |

### Additional Features
- 🔍 **Global search** across name, ID, email, city
- 🔽 **Filters** by department, year of study, status, gender
- 📊 **Sorting** by any column (asc/desc)
- 📄 **Pagination** (10 records per page)
- 📈 **Dashboard** with live stats and department breakdown
- 🔔 **Toast notifications** (success/error/info)
- ✅ **Confirmation dialogs** before destructive actions
- 👁️ **Password visibility toggle** on login
- 🌐 **Responsive design** (desktop, tablet, mobile)
- 🔒 **Token-based authentication**
- 🛡️ **Backend-enforced authorization** (not just hidden buttons)

---

## 4. Technology Stack

### Backend
| Technology | Version | Purpose |
|-----------|---------|---------|
| Python | 3.x | Core language |
| Django | 6.1.1 | Web framework |
| Django REST Framework | 3.18.1 | REST API |
| django-cors-headers | 4.9.0 | CORS management |
| python-dotenv | 1.2.2 | Environment variables |
| SQLite | Built-in | Development database |

### Frontend
| Technology | Purpose |
|-----------|---------|
| HTML5 | Semantic markup |
| CSS3 (Custom) | Professional styling, animations |
| Vanilla JavaScript (ES6+) | SPA routing, API calls, DOM manipulation |
| Remix Icons | Icon library (CDN) |
| Google Fonts — Inter | Typography (CDN) |

### DevOps & Tools
| Tool | Purpose |
|-----|---------|
| Git | Version control |
| GitHub | Remote repository |
| Postman | API testing |
| SQLite Browser | Database inspection |

---

## 5. System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                      BROWSER (Client)                    │
│  ┌────────────────────────────────────────────────────┐  │
│  │         Single-Page Application (SPA)              │  │
│  │  HTML5 + CSS3 + Vanilla JS (Hash-based Router)     │  │
│  │  Pages: Login · Register · Dashboard · Students   │  │
│  │         Departments · Profile · Users              │  │
│  └───────────────────┬────────────────────────────────┘  │
└──────────────────────│──────────────────────────────────┘
                       │  HTTP/REST (Token Auth)
                       ▼
┌─────────────────────────────────────────────────────────┐
│                   Django Backend                         │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────┐  │
│  │  accounts/   │  │  students/   │  │  sms_project/ │  │
│  │  - Register  │  │  - CRUD      │  │  - Settings   │  │
│  │  - Login     │  │  - Search    │  │  - URLs       │  │
│  │  - Logout    │  │  - Filter    │  │  - WSGI       │  │
│  │  - Profile   │  │  - Dashboard │  │               │  │
│  │  - Users     │  │  - Depts     │  │               │  │
│  └──────────────┘  └──────────────┘  └───────────────┘  │
│                         │                                │
│              Django ORM (parameterised)                  │
└─────────────────────────│───────────────────────────────┘
                          │
                          ▼
             ┌────────────────────────┐
             │     SQLite Database    │
             │  accounts_user         │
             │  students_department   │
             │  students_student      │
             │  authtoken_token       │
             └────────────────────────┘
```

### Request Flow
```
User Action → SPA Router → API.request() → Django URL → View
→ Permission Check → Serializer Validation → ORM → DB
→ JSON Response → JS Handler → DOM Update → Toast/Modal
```

---

## 6. Database Design

### `accounts_user` (Custom User Model)
| Field | Type | Constraints |
|-------|------|-------------|
| id | BigAutoField | PK |
| email | EmailField | UNIQUE, NOT NULL |
| username | CharField(150) | UNIQUE |
| first_name | CharField(100) | |
| last_name | CharField(100) | |
| role | CharField(10) | choices: admin/staff |
| phone | CharField(15) | blank |
| password | CharField | Hashed (PBKDF2) |
| is_active | BooleanField | default: True |
| created_at | DateTimeField | auto_now_add |
| updated_at | DateTimeField | auto_now |

### `students_department`
| Field | Type | Constraints |
|-------|------|-------------|
| id | BigAutoField | PK |
| name | CharField(100) | UNIQUE |
| code | CharField(10) | UNIQUE |
| created_at | DateTimeField | auto_now_add |

### `students_student`
| Field | Type | Constraints |
|-------|------|-------------|
| id | BigAutoField | PK |
| student_id | CharField(20) | UNIQUE, UPPERCASE, alphanumeric |
| first_name | CharField(100) | NOT NULL |
| last_name | CharField(100) | NOT NULL |
| email | EmailField | UNIQUE |
| phone | CharField(15) | regex validated |
| gender | CharField(1) | M/F/O |
| date_of_birth | DateField | |
| department | FK(Department) | PROTECT |
| year_of_study | SmallInt | 1–5 |
| section | CharField(5) | |
| cgpa | DecimalField(4,2) | 0–10, nullable |
| status | CharField(20) | active/inactive/graduated/dropped |
| address | TextField | blank |
| city | CharField(100) | blank |
| state | CharField(100) | blank |
| created_at | DateTimeField | auto_now_add |
| updated_at | DateTimeField | auto_now |
| created_by | FK(User) | SET_NULL |

**Indexes:** `student_id`, `email`, `(department, year_of_study)`, `status`

### Entity-Relationship Diagram
```
User ────< Student (created_by) >──── 1
Department ────< Student (department) >──── many
```

---

## 7. CRUD Explanation

### CREATE — `POST /api/students/`
- Admin opens "Add Student" modal
- Fills form with all required fields
- Frontend validates: required fields, email format, CGPA range
- Request sent with `Authorization: Token <token>` header
- Backend: checks admin role → runs serializer validation → saves to DB
- Response: `201 Created` with new record + success message
- UI: modal closes, toast shown, table refreshes

### READ — `GET /api/students/` & `GET /api/students/<id>/`
- All authenticated users can read
- List endpoint supports: `?search=`, `?department=`, `?status=`, `?year=`, `?ordering=`, `?page=`
- Detail endpoint returns full record via `StudentDetailSerializer`
- "View" button in table opens a detail modal with all fields

### UPDATE — `PATCH /api/students/<id>/`
- Admin clicks "Edit" on any row
- Modal pre-fills with existing data
- Only changed fields sent (partial update via PATCH)
- Backend validates, saves, returns updated record
- Response: `200 OK` with updated data + message
- UI: modal closes, table row refreshes, toast shown

### DELETE — `DELETE /api/students/<id>/`
- Admin clicks "Delete" button
- Confirmation dialog appears with student name
- On confirm: `DELETE /api/students/<id>/` sent
- Backend checks admin role → removes record
- Response: `200 OK` with success message
- UI: dialog closes, toast shown, table refreshes

---

## 8. API Documentation

### Base URL
```
http://127.0.0.1:8000/api
```

### Authentication Header
```
Authorization: Token <your_token_here>
```

### Auth Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/auth/register/` | None | Register new user |
| POST | `/auth/login/` | None | Login, receive token |
| POST | `/auth/logout/` | Token | Invalidate token |
| GET  | `/auth/profile/` | Token | Get own profile |
| PUT/PATCH | `/auth/profile/` | Token | Update profile |
| POST | `/auth/change-password/` | Token | Change password |
| GET  | `/auth/users/` | Admin | List all users |

### Student Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/students/` | Token | List/search/filter students |
| POST | `/students/` | Admin | Create student |
| GET | `/students/<id>/` | Token | Get student details |
| PATCH | `/students/<id>/` | Admin | Partially update student |
| PUT | `/students/<id>/` | Admin | Fully update student |
| DELETE | `/students/<id>/` | Admin | Delete student |
| GET | `/students/dashboard/` | Token | Dashboard statistics |
| GET | `/students/departments/` | Token | List departments |
| POST | `/students/departments/` | Admin | Create department |

### Query Parameters (GET `/students/`)

| Parameter | Example | Description |
|-----------|---------|-------------|
| `search` | `?search=Arjun` | Search name, ID, email, city |
| `department` | `?department=1` | Filter by department ID |
| `year` | `?year=3` | Filter by year of study |
| `status` | `?status=active` | Filter by status |
| `gender` | `?gender=M` | Filter by gender |
| `ordering` | `?ordering=-cgpa` | Sort (prefix `-` for descending) |
| `page` | `?page=2` | Pagination (10 per page) |

### HTTP Status Codes Used

| Code | Meaning |
|------|---------|
| 200 | OK — successful GET/PATCH/DELETE |
| 201 | Created — successful POST |
| 400 | Bad Request — validation error |
| 401 | Unauthorized — missing/invalid token |
| 403 | Forbidden — insufficient role |
| 404 | Not Found — record doesn't exist |
| 500 | Server Error — unexpected failure |

### Example: Login Request & Response

**Request:**
```json
POST /api/auth/login/
Content-Type: application/json

{
  "email": "admin@college.edu",
  "password": "Admin@1234"
}
```

**Response (200):**
```json
{
  "message": "Login successful.",
  "token": "9f4a8b2c1d...",
  "user": {
    "id": 1,
    "email": "admin@college.edu",
    "full_name": "System Administrator",
    "role": "admin",
    "is_admin": true
  }
}
```

### Example: Create Student

**Request:**
```json
POST /api/students/
Authorization: Token 9f4a8b2c1d...
Content-Type: application/json

{
  "student_id": "24CSE001",
  "first_name": "Arjun",
  "last_name": "Kumar",
  "email": "arjun.kumar@college.edu",
  "phone": "+91 9876543210",
  "gender": "M",
  "date_of_birth": "2004-05-15",
  "department": 1,
  "year_of_study": 3,
  "section": "A",
  "cgpa": "8.75",
  "status": "active"
}
```

**Response (201):**
```json
{
  "message": "Student added successfully.",
  "data": {
    "id": 11,
    "student_id": "24CSE001",
    "full_name": "Arjun Kumar",
    ...
  }
}
```

**Validation Error (400):**
```json
{
  "errors": {
    "email": ["A student with this email already exists."],
    "cgpa": ["Ensure this value is less than or equal to 10."]
  }
}
```

---

## 9. Security Features

| Security Concern | Implementation |
|-----------------|---------------|
| Password storage | Django PBKDF2-SHA256 hashing (never plain-text) |
| Authentication | Token-based (DRF `authtoken`) |
| Authorization | Backend-enforced role checks on every endpoint |
| SQL Injection | Django ORM with parameterised queries only |
| XSS | Django template auto-escaping; DOM manipulation via `textContent` |
| CSRF | Django CSRF middleware enabled |
| Secret management | `.env` file + `python-dotenv`; never hard-coded |
| Error messages | Generic messages (no account enumeration via login errors) |
| Password exposure | Passwords never appear in any API response |
| CORS | Restricted to configured origins via `django-cors-headers` |
| Session security | `SESSION_COOKIE_HTTPONLY = True` |
| Clickjacking | `X_FRAME_OPTIONS = 'DENY'` |
| Input validation | Both frontend (real-time) and backend (serializer) |
| Token invalidation | Token deleted on logout (one-session model) |

---

## 10. Installation Steps

### Prerequisites
- Python 3.10 or higher — [python.org](https://www.python.org/downloads/)
- pip (comes with Python)
- Git — [git-scm.com](https://git-scm.com/)
- Postman (for API testing) — [postman.com](https://www.postman.com/)

### Step 1 — Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/student-management-system.git
cd student-management-system
```

### Step 2 — Create Virtual Environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

You should see `(venv)` in your terminal prompt.

### Step 3 — Install Dependencies
```bash
pip install -r requirements.txt
```

---

## 11. Environment Setup

### Copy the example env file
```bash
# Windows
copy .env.example .env

# macOS / Linux
cp .env.example .env
```

### Edit `.env` (open in any text editor)
```env
SECRET_KEY=django-insecure-change-this-to-a-random-string-in-production
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1
DB_ENGINE=django.db.backends.sqlite3
DB_NAME=db.sqlite3
CORS_ALLOWED_ORIGINS=http://localhost:8000,http://127.0.0.1:8000
```

> ⚠️ **Never commit the real `.env` file to Git.** The `.gitignore` already excludes it.

---

## 12. Database Migration & Seeding

### Run migrations (creates all database tables)
```bash
python manage.py makemigrations
python manage.py migrate
```

### Seed demo data (departments, students, demo users)
```bash
python manage.py seed_data
```

This creates:

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@college.edu` | `Admin@1234` |
| Staff | `staff@college.edu` | `Staff@1234` |

And 10 sample students across 6 departments.

### (Optional) Create your own superuser
```bash
python manage.py createsuperuser
```

---

## 13. Running the Application

### Start the Django development server
```bash
python manage.py runserver
```

Open your browser and go to:
```
http://127.0.0.1:8000
```

The SPA will load and redirect to the login page. Use the demo credentials above.

### Django Admin Panel
```
http://127.0.0.1:8000/admin/
```
Login with the superuser or admin credentials.

---

## 14. Postman API Testing

### Import the Collection
1. Open Postman
2. Click **Import** → **Upload Files**
3. Select `SMS_Postman_Collection.json`
4. The collection "Student Management System — API" will appear

### Setup Collection Variable
1. Click the collection name → **Variables** tab
2. Set `base_url` to `http://127.0.0.1:8000`

### Run Order
Execute the requests in this order:

| Step | Request | Expected Status |
|------|---------|----------------|
| 1 | Login (Admin) | 200 — token auto-saved |
| 2 | Dashboard Stats | 200 |
| 3 | List all students | 200 |
| 4 | Search students | 200 |
| 5 | Filter by status | 200 |
| 6 | Get single student | 200 |
| 7 | Get nonexistent (404) | 404 |
| 8 | Create student | 201 |
| 9 | Create — missing fields | 400 |
| 10 | Update student (PATCH) | 200 |
| 11 | Delete student | 200 |
| 12 | Unauthorized request | 401 |
| 13 | Login (wrong password) | 400 |
| 14 | List departments | 200 |
| 15 | Logout | 200 |

### Testing Tips
- The **Login** request auto-saves `{{token}}` to the collection variable via a test script.
- The **List students** request auto-saves `{{student_id}}` for use in detail/update/delete requests.
- All protected requests use `Authorization: Token {{token}}` automatically.

---

## 15. Test Suite

The project includes **40 automated tests** covering all major functionality.

### Run all tests
```bash
python manage.py test students --verbosity=2
```

### Test Categories

| Category | Tests | Coverage |
|----------|-------|---------|
| Authentication | 11 | Register, login, logout, profile, change password |
| CRUD — Students | 14 | List, retrieve, create, update, delete |
| Search & Filter | 5 | Search by name/ID, filter by dept/status, ordering |
| Dashboard | 2 | Stats, unauthenticated access |
| Authorization | 8 | Staff restrictions, admin access, unauthenticated |

### Test Checklist (for college evaluation)

- [x] Registration creates user with hashed password
- [x] Duplicate email rejected on registration
- [x] Mismatched passwords rejected on registration
- [x] Login succeeds with correct credentials
- [x] Login fails with wrong password (generic error message)
- [x] Login fails for non-existent user
- [x] Logout invalidates token
- [x] Unauthenticated requests return 401
- [x] Staff cannot create students (403)
- [x] Staff cannot edit students (403)
- [x] Staff cannot delete students (403)
- [x] Staff cannot list users (403)
- [x] Admin can perform all CRUD operations
- [x] Missing required fields return 400 with field-level errors
- [x] Duplicate student_id rejected
- [x] Duplicate email rejected
- [x] Invalid CGPA (>10) rejected
- [x] Nonexistent record returns 404
- [x] Search by name filters correctly
- [x] Search by student ID filters correctly
- [x] Filter by department works
- [x] Filter by status works
- [x] Dashboard stats return correct fields
- [x] Password never appears in any API response

---

## 16. Project Structure

```
student-management-system/
│
├── sms_project/               # Django project configuration
│   ├── settings.py            # Settings with env var support
│   ├── urls.py                # Root URL config
│   └── wsgi.py
│
├── accounts/                  # Authentication app
│   ├── models.py              # Custom User model (email-based login)
│   ├── serializers.py         # Register, Login, User, ChangePassword
│   ├── views.py               # Register, Login, Logout, Profile, Users
│   ├── urls.py
│   └── admin.py
│
├── students/                  # Core CRUD app
│   ├── models.py              # Student, Department models
│   ├── serializers.py         # List, Detail serializers
│   ├── views.py               # CRUD views with role checks
│   ├── permissions.py         # IsAdminUser, IsAdminOrReadOnly
│   ├── urls.py
│   ├── admin.py
│   ├── tests.py               # 40 automated tests
│   └── management/
│       └── commands/
│           └── seed_data.py   # Demo data seeder
│
├── static/
│   ├── css/
│   │   └── sms.css            # Complete custom stylesheet
│   └── js/
│       └── app.js             # SPA (Router, Auth, Pages, API)
│
├── templates/
│   └── index.html             # SPA shell template
│
├── .env                       # Local environment variables (git-ignored)
├── .env.example               # Safe placeholder for sharing
├── .gitignore
├── manage.py
├── requirements.txt           # Python dependencies
├── SMS_Postman_Collection.json
└── README.md
```

---

## 17. Screenshots

> _Replace with actual screenshots during final submission._

| Screen | Description |
|--------|-------------|
| `screenshots/login.png` | Two-column login page matching design reference |
| `screenshots/dashboard.png` | Stats cards, recent students, dept breakdown |
| `screenshots/students_list.png` | Table with search/filter/sort/pagination |
| `screenshots/add_student.png` | Modal form with validation |
| `screenshots/student_detail.png` | Full student detail modal |
| `screenshots/mobile.png` | Responsive single-column mobile layout |
| `screenshots/postman_login.png` | Postman login request/response |
| `screenshots/postman_crud.png` | Postman CRUD requests |

---

## 18. Future Enhancements

1. **Attendance Tracking** — Per-student daily attendance with percentage calculation
2. **Marks / Grade Management** — Subject-wise marks entry and grade computation
3. **PDF Reports** — Export student lists and individual records to PDF
4. **Email Notifications** — Automated emails on record creation or status change
5. **Bulk Import** — CSV/Excel upload for mass student record creation
6. **Photo Upload** — Student profile photo with Pillow processing
7. **MySQL / PostgreSQL Migration** — Production-grade database (config already in `.env`)
8. **Docker Deployment** — `Dockerfile` + `docker-compose.yml` for containerised deployment
9. **Advanced Analytics** — CGPA trends, year-wise graphs using Chart.js
10. **Password Reset** — Email-based password reset flow
11. **Two-Factor Authentication (2FA)** — OTP-based login for admin accounts
12. **Audit Log** — Track every create/update/delete with who did it and when

---

## 19. Advantages

- **Zero build step** — No npm, no React build; runs with just `pip install` and `python manage.py runserver`
- **40 automated tests** — Confidence that nothing is broken between changes
- **Backend-enforced security** — Authorization checked on the server; cannot be bypassed by editing frontend JS
- **Clean REST API** — Fully Postman-testable with proper HTTP methods and status codes
- **Responsive design** — Works on desktop, tablet, and mobile without any media-query hacks
- **Production-ready patterns** — Environment variables, token auth, CSRF, ORM parameterisation
- **Easy database migration** — Changing one line in `.env` switches from SQLite to PostgreSQL

---

## 20. Limitations

- **SQLite concurrency** — Not suitable for multiple simultaneous writes in production (intended; use PostgreSQL for production)
- **No file upload** — Student photos not implemented in this version
- **No email service** — Password reset and notifications require SMTP configuration (not included)
- **Single server** — No load balancing; single Django `runserver` process
- **No real-time updates** — Table does not auto-refresh if another user changes data (requires WebSockets)

---

## 21. Conclusion

The Student Management System demonstrates a complete, end-to-end mini web application that covers all requirements of a modern CRUD project: secure authentication, role-based authorization, full REST API, automated tests, professional UI, and thorough documentation. It is built using industry-standard tools and practices, making it not just a college submission but a reference for real-world full-stack development patterns.

---

## 22. GitHub Usage

### Initialize and push to GitHub

```bash
# 1. Initialize git (if not already done)
git init

# 2. Add .gitignore
echo "venv/
__pycache__/
*.pyc
.env
db.sqlite3
staticfiles/
media/
*.egg-info/
.DS_Store
Thumbs.db" > .gitignore

# 3. Stage all files
git add .

# 4. Initial commit
git commit -m "Initial commit: Student Management System by SARANEESH S"

# 5. Add remote (replace with your GitHub URL)
git remote add origin https://github.com/YOUR_USERNAME/student-management-system.git

# 6. Push
git push -u origin main
```

### Subsequent updates
```bash
git add .
git commit -m "feat: add attendance tracking module"
git push
```

### Recommended branch strategy
```bash
git checkout -b feature/attendance   # new feature
# ... develop ...
git checkout main
git merge feature/attendance
git push
```

---

*Student Management System — Built by **SARANEESH S** | V.S.B. Engineering College, Karur*
