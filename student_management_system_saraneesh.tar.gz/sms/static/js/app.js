/* ============================================================
   Student Management System — Frontend Application
   Author: SARANEESH S
   ============================================================ */

'use strict';

/* ---- API helpers ---- */
const API = {
  base: '/api',

  getToken() { return localStorage.getItem('sms_token'); },

  headers(extra = {}) {
    const h = { 'Content-Type': 'application/json', ...extra };
    const t = this.getToken();
    if (t) h['Authorization'] = `Token ${t}`;
    return h;
  },

  async request(method, endpoint, body = null) {
    const opts = { method, headers: this.headers() };
    if (body) opts.body = JSON.stringify(body);
    try {
      const res = await fetch(`${this.base}${endpoint}`, opts);
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const msg = data.errors || data.detail || data.message || 'Request failed.';
        throw { status: res.status, message: msg, data };
      }
      return data;
    } catch (err) {
      if (err.status) throw err;
      throw { status: 0, message: 'Network error. Please try again.' };
    }
  },

  get:    (ep)     => API.request('GET',    ep),
  post:   (ep, b)  => API.request('POST',   ep, b),
  put:    (ep, b)  => API.request('PUT',    ep, b),
  patch:  (ep, b)  => API.request('PATCH',  ep, b),
  delete: (ep)     => API.request('DELETE', ep),
};

/* ---- Toast notifications ---- */
const Toast = {
  container: null,
  init() {
    this.container = document.getElementById('toast-container');
  },
  show(type, title, message, duration = 4000) {
    if (!this.container) this.init();
    const icons = { success: 'ri-checkbox-circle-fill', error: 'ri-error-warning-fill', info: 'ri-information-fill', warning: 'ri-alert-fill' };
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `
      <i class="toast-icon ${icons[type] || icons.info}"></i>
      <div class="toast-content">
        <div class="toast-title">${title}</div>
        ${message ? `<div class="toast-message">${message}</div>` : ''}
      </div>
      <button class="toast-close" onclick="this.closest('.toast').remove()"><i class="ri-close-line"></i></button>`;
    this.container.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, duration);
  },
  success: (t, m) => Toast.show('success', t, m),
  error:   (t, m) => Toast.show('error', t, m),
  info:    (t, m) => Toast.show('info', t, m),
  warning: (t, m) => Toast.show('warning', t, m),
};

/* ---- Modal helper ---- */
const Modal = {
  open(id)  { document.getElementById(id)?.classList.add('show'); document.body.style.overflow = 'hidden'; },
  close(id) { document.getElementById(id)?.classList.remove('show'); document.body.style.overflow = ''; },
  closeAll() { document.querySelectorAll('.modal-overlay.show').forEach(m => m.classList.remove('show')); document.body.style.overflow = ''; },
};

/* ---- Loading button helper ---- */
function setLoading(btn, loading, text = '') {
  if (loading) {
    btn._origHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="loading-spinner"></span>${text ? ' ' + text : ''}`;
  } else {
    btn.disabled = false;
    btn.innerHTML = btn._origHTML || text;
  }
}

/* ---- Avatar color from name ---- */
function avatarColor(name = '') {
  const colors = ['#2577d4','#1a7a4a','#7c3aed','#b45309','#0369a1','#c0392b','#0891b2','#65a30d'];
  let hash = 0;
  for (const c of name) hash = ((hash << 5) - hash) + c.charCodeAt(0);
  return colors[Math.abs(hash) % colors.length];
}

function initials(name = '') {
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) || 'ST';
}

/* ---- Format helpers ---- */
function formatDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function statusBadge(status) {
  const map = {
    active:    ['badge-active',    'Active'],
    inactive:  ['badge-inactive',  'Inactive'],
    graduated: ['badge-graduated', 'Graduated'],
    dropped:   ['badge-dropped',   'Dropped'],
  };
  const [cls, label] = map[status] || ['badge-inactive', status];
  return `<span class="badge ${cls}"><span class="badge-dot"></span>${label}</span>`;
}

/* ---- Validation helpers ---- */
function showFieldError(inputEl, msg) {
  inputEl.classList.add('is-invalid');
  const err = inputEl.parentElement.querySelector('.field-error') || inputEl.closest('.form-group')?.querySelector('.field-error');
  if (err) { err.textContent = msg; err.classList.add('show'); }
}
function clearFieldErrors(form) {
  form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
  form.querySelectorAll('.field-error').forEach(el => { el.textContent = ''; el.classList.remove('show'); });
}
function renderApiErrors(errors, form) {
  if (typeof errors === 'string') { Toast.error('Error', errors); return; }
  for (const [key, msgs] of Object.entries(errors)) {
    const el = form?.querySelector(`[name="${key}"]`);
    const msg = Array.isArray(msgs) ? msgs[0] : msgs;
    if (el) showFieldError(el, msg);
    else Toast.error('Validation Error', `${key}: ${msg}`);
  }
}

/* ============================================================
   AUTH MODULE
   ============================================================ */
const Auth = {
  user: null,

  init() {
    const token = API.getToken();
    const userStr = localStorage.getItem('sms_user');
    if (token && userStr) {
      this.user = JSON.parse(userStr);
      return true;
    }
    return false;
  },

  save(token, user) {
    localStorage.setItem('sms_token', token);
    localStorage.setItem('sms_user', JSON.stringify(user));
    this.user = user;
  },

  clear() {
    localStorage.removeItem('sms_token');
    localStorage.removeItem('sms_user');
    this.user = null;
  },

  isAdmin() { return this.user?.is_admin; },
};

/* ============================================================
   ROUTER (hash-based SPA)
   ============================================================ */
const Router = {
  routes: {},
  currentPage: null,

  register(hash, handler) { this.routes[hash] = handler; },

  navigate(hash) {
    window.location.hash = hash;
  },

  init() {
    window.addEventListener('hashchange', () => this.handle());
    this.handle();
  },

  handle() {
    const hash = window.location.hash.slice(1) || 'login';
    const isAuth = Auth.init();

    // Redirect logic
    if (!isAuth && hash !== 'login' && hash !== 'register') {
      window.location.hash = 'login'; return;
    }
    if (isAuth && (hash === 'login' || hash === 'register')) {
      window.location.hash = 'dashboard'; return;
    }

    const handler = this.routes[hash];
    if (handler) { this.currentPage = hash; handler(); }
    else if (isAuth) Pages.notFound();
    else window.location.hash = 'login';
  },
};

/* ============================================================
   APP SHELL
   ============================================================ */
const Shell = {
  rendered: false,

  render() {
    if (this.rendered) return;
    this.rendered = true;
    document.getElementById('app').innerHTML = `
      <div id="toast-container"></div>
      <div class="app-layout">
        ${this.sidebar()}
        <div class="sidebar-overlay" id="sidebarOverlay"></div>
        <main class="main-content">
          ${this.topbar()}
          <div class="page-content" id="pageContent"></div>
        </main>
      </div>`;
    this.bindEvents();
    this.updateUser();
  },

  sidebar() {
    const user = Auth.user;
    const isAdmin = Auth.isAdmin();
    return `
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-brand">
        <div class="sidebar-brand-icon"><i class="ri-graduation-cap-fill"></i></div>
        <div class="sidebar-brand-text">
          <h3>Student Management</h3>
          <p>Academic Portal</p>
        </div>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-section-label">Main</div>
        <button class="nav-item" data-page="dashboard"><i class="ri-dashboard-line"></i>Dashboard</button>
        <button class="nav-item" data-page="students"><i class="ri-group-line"></i>Students</button>
        ${isAdmin ? `<button class="nav-item" data-page="departments"><i class="ri-building-line"></i>Departments</button>` : ''}
        <div class="nav-section-label">Account</div>
        <button class="nav-item" data-page="profile"><i class="ri-user-settings-line"></i>My Profile</button>
        ${isAdmin ? `<button class="nav-item" data-page="users"><i class="ri-shield-user-line"></i>Users</button>` : ''}
      </nav>
      <div class="sidebar-footer">
        <div class="sidebar-user" id="sidebarUser">
          <div class="sidebar-avatar" id="sidebarAvatar">${initials(user?.full_name || user?.email || '')}</div>
          <div class="sidebar-user-info">
            <div class="name" id="sidebarName">${user?.full_name || user?.email || 'User'}</div>
            <div class="role" id="sidebarRole">${isAdmin ? 'Administrator' : 'Staff Member'}</div>
          </div>
          <button class="btn btn-ghost btn-icon-only" id="logoutBtn" title="Logout">
            <i class="ri-logout-box-r-line" style="color:rgba(255,255,255,0.5)"></i>
          </button>
        </div>
      </div>
    </aside>`;
  },

  topbar() {
    return `
    <header class="topbar">
      <div class="topbar-left">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="ri-menu-line"></i></button>
        <div>
          <div class="topbar-title" id="topbarTitle">Dashboard</div>
          <div class="topbar-breadcrumb" id="topbarBreadcrumb">Home / Dashboard</div>
        </div>
      </div>
      <div class="topbar-right">
        <span style="font-size:12px;color:var(--text-muted)" id="topbarUserName"></span>
      </div>
    </header>`;
  },

  updateUser() {
    const user = Auth.user;
    if (!user) return;
    const avatar = document.getElementById('sidebarAvatar');
    if (avatar) { avatar.textContent = initials(user.full_name || user.email); avatar.style.background = avatarColor(user.full_name || ''); }
    const el = document.getElementById('topbarUserName');
    if (el) el.textContent = user.full_name || user.email;
  },

  bindEvents() {
    document.querySelectorAll('.nav-item[data-page]').forEach(btn => {
      btn.addEventListener('click', () => Router.navigate(btn.dataset.page));
    });
    document.getElementById('logoutBtn')?.addEventListener('click', Pages.confirmLogout);
    const toggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    toggle?.addEventListener('click', () => { sidebar.classList.toggle('open'); overlay.classList.toggle('show'); });
    overlay?.addEventListener('click', () => { sidebar.classList.remove('open'); overlay.classList.remove('show'); });
  },

  setActive(page) {
    document.querySelectorAll('.nav-item[data-page]').forEach(b => b.classList.toggle('active', b.dataset.page === page));
    const titles = { dashboard: 'Dashboard', students: 'Students', departments: 'Departments', profile: 'My Profile', users: 'User Management' };
    document.getElementById('topbarTitle').textContent = titles[page] || page;
    document.getElementById('topbarBreadcrumb').textContent = `Home / ${titles[page] || page}`;
  },

  reset() { this.rendered = false; document.getElementById('app').innerHTML = '<div id="toast-container"></div>'; },
};

/* ============================================================
   PAGES
   ============================================================ */
const Pages = {

  /* ---- Login ---- */
  login() {
    document.getElementById('app').innerHTML = `
      <div id="toast-container"></div>
      <div class="auth-page">
        <div class="auth-left">
          <div class="auth-brand">
            <div class="auth-brand-icon"><i class="ri-graduation-cap-fill"></i></div>
            <div class="auth-brand-text"><h2>Student Management System</h2><p>Manage Students · Streamline Academics · Build a Better Future</p></div>
          </div>
          <div class="auth-hero">
            <h1>Welcome Back!</h1>
            <p>Sign in to your account to access the student management system and manage student records, attendance, and more.</p>
            <div class="auth-features">
              <div class="auth-feature"><div class="auth-feature-icon blue"><i class="ri-group-fill"></i></div><div class="auth-feature-label">Manage Students</div></div>
              <div class="auth-feature"><div class="auth-feature-icon green"><i class="ri-calendar-check-fill"></i></div><div class="auth-feature-label">Track Attendance</div></div>
              <div class="auth-feature"><div class="auth-feature-icon purple"><i class="ri-bar-chart-box-fill"></i></div><div class="auth-feature-label">View Reports</div></div>
              <div class="auth-feature"><div class="auth-feature-icon orange"><i class="ri-shield-check-fill"></i></div><div class="auth-feature-label">Secure & Reliable</div></div>
            </div>
            <div class="auth-campus" style="margin-top:2rem">
              <div class="auth-campus-placeholder">
                <div style="text-align:center;color:rgba(255,255,255,0.5)">
                  <i class="ri-building-4-fill" style="font-size:64px;display:block;margin-bottom:8px"></i>
                  <span style="font-size:13px">V.S.B. Engineering College, Karur</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="auth-right">
          <div class="auth-card">
            <div class="auth-card-header">
              <div class="auth-card-logo"><i class="ri-graduation-cap-fill"></i></div>
              <h3>Student Management System</h3>
              <p>Login to Continue</p>
            </div>
            <form id="loginForm" novalidate>
              <div class="form-group">
                <label class="form-label">Email Address</label>
                <div class="input-wrap">
                  <i class="input-icon ri-mail-line"></i>
                  <input type="email" class="form-input" name="email" placeholder="Enter your email" autocomplete="email" required>
                </div>
                <div class="field-error"></div>
              </div>
              <div class="form-group">
                <label class="form-label">Password</label>
                <div class="input-wrap">
                  <i class="input-icon ri-lock-line"></i>
                  <input type="password" class="form-input" name="password" placeholder="Enter your password" autocomplete="current-password" required>
                  <button type="button" class="input-icon-right" id="togglePwd"><i class="ri-eye-line"></i></button>
                </div>
                <div class="field-error"></div>
              </div>
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem">
                <label class="form-check">
                  <input type="checkbox" class="form-check-input" name="remember">
                  <span class="form-check-label">Remember me</span>
                </label>
              </div>
              <div id="loginError" style="display:none;background:var(--danger-bg);color:var(--danger);padding:10px 14px;border-radius:var(--radius-sm);font-size:13px;margin-bottom:1rem;border-left:3px solid var(--danger)"></div>
              <button type="submit" class="btn btn-primary btn-full btn-lg" id="loginBtn">Login <i class="ri-arrow-right-line"></i></button>
            </form>
            <div class="divider">or</div>
            <div class="auth-link">Don't have an account? <a href="#register">Register here</a></div>
            <div style="margin-top:1rem;padding:0.75rem;background:var(--info-bg);border-radius:var(--radius-sm);font-size:12px;color:var(--info)">
              <strong>Demo:</strong> admin@college.edu / Admin@1234
            </div>
          </div>
        </div>
      </div>`;
    Toast.init();

    // Password toggle
    document.getElementById('togglePwd')?.addEventListener('click', function() {
      const inp = document.querySelector('input[name="password"]');
      const isText = inp.type === 'text';
      inp.type = isText ? 'password' : 'text';
      this.querySelector('i').className = isText ? 'ri-eye-line' : 'ri-eye-off-line';
    });

    document.getElementById('loginForm')?.addEventListener('submit', async function(e) {
      e.preventDefault();
      clearFieldErrors(this);
      const btn = document.getElementById('loginBtn');
      const errDiv = document.getElementById('loginError');
      errDiv.style.display = 'none';
      const email = this.email.value.trim();
      const password = this.password.value;
      let valid = true;
      if (!email) { showFieldError(this.email, 'Email is required.'); valid = false; }
      else if (!/\S+@\S+\.\S+/.test(email)) { showFieldError(this.email, 'Enter a valid email address.'); valid = false; }
      if (!password) { showFieldError(this.password, 'Password is required.'); valid = false; }
      if (!valid) return;
      setLoading(btn, true, 'Signing in…');
      try {
        const data = await API.post('/auth/login/', { email, password });
        Auth.save(data.token, data.user);
        Shell.reset();
        Shell.render();
        Router.navigate('dashboard');
        Toast.success('Welcome back!', `Hello, ${data.user.first_name || data.user.email}`);
      } catch (err) {
        const msg = typeof err.message === 'string' ? err.message : (err.message?.non_field_errors?.[0] || 'Invalid email or password.');
        errDiv.textContent = msg;
        errDiv.style.display = 'block';
        setLoading(btn, false);
      }
    });
  },

  /* ---- Register ---- */
  register() {
    document.getElementById('app').innerHTML = `
      <div id="toast-container"></div>
      <div class="auth-page">
        <div class="auth-left">
          <div class="auth-brand">
            <div class="auth-brand-icon"><i class="ri-graduation-cap-fill"></i></div>
            <div class="auth-brand-text"><h2>Student Management System</h2><p>Manage Students · Streamline Academics</p></div>
          </div>
          <div class="auth-hero">
            <h1>Create Your Account</h1>
            <p>Join the system to manage student records securely and efficiently across departments.</p>
            <div class="auth-features">
              <div class="auth-feature"><div class="auth-feature-icon blue"><i class="ri-shield-check-fill"></i></div><div class="auth-feature-label">Secure Access</div></div>
              <div class="auth-feature"><div class="auth-feature-icon green"><i class="ri-database-fill"></i></div><div class="auth-feature-label">Persistent Data</div></div>
              <div class="auth-feature"><div class="auth-feature-icon purple"><i class="ri-team-fill"></i></div><div class="auth-feature-label">Role-Based</div></div>
              <div class="auth-feature"><div class="auth-feature-icon orange"><i class="ri-smartphone-fill"></i></div><div class="auth-feature-label">Mobile Ready</div></div>
            </div>
          </div>
        </div>
        <div class="auth-right" style="padding:1rem">
          <div class="auth-card" style="max-width:460px">
            <div class="auth-card-header">
              <div class="auth-card-logo" style="width:52px;height:52px;font-size:22px"><i class="ri-user-add-fill"></i></div>
              <h3>Create Account</h3>
              <p>Register as staff member</p>
            </div>
            <form id="registerForm" novalidate>
              <div class="form-row cols-2">
                <div class="form-group">
                  <label class="form-label">First Name <span class="required">*</span></label>
                  <input type="text" class="form-input no-icon" name="first_name" placeholder="First name" required>
                  <div class="field-error"></div>
                </div>
                <div class="form-group">
                  <label class="form-label">Last Name <span class="required">*</span></label>
                  <input type="text" class="form-input no-icon" name="last_name" placeholder="Last name" required>
                  <div class="field-error"></div>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Email Address <span class="required">*</span></label>
                <div class="input-wrap">
                  <i class="input-icon ri-mail-line"></i>
                  <input type="email" class="form-input" name="email" placeholder="Your email address" required>
                </div>
                <div class="field-error"></div>
              </div>
              <div class="form-group">
                <label class="form-label">Username <span class="required">*</span></label>
                <div class="input-wrap">
                  <i class="input-icon ri-at-line"></i>
                  <input type="text" class="form-input" name="username" placeholder="Choose a username" required>
                </div>
                <div class="field-error"></div>
              </div>
              <div class="form-row cols-2">
                <div class="form-group">
                  <label class="form-label">Password <span class="required">*</span></label>
                  <div class="input-wrap">
                    <i class="input-icon ri-lock-line"></i>
                    <input type="password" class="form-input" name="password" placeholder="Min 8 characters" required>
                    <button type="button" class="input-icon-right toggle-pwd"><i class="ri-eye-line"></i></button>
                  </div>
                  <div class="field-error"></div>
                </div>
                <div class="form-group">
                  <label class="form-label">Confirm Password <span class="required">*</span></label>
                  <div class="input-wrap">
                    <i class="input-icon ri-lock-2-line"></i>
                    <input type="password" class="form-input" name="password_confirm" placeholder="Repeat password" required>
                  </div>
                  <div class="field-error"></div>
                </div>
              </div>
              <div id="regError" style="display:none;background:var(--danger-bg);color:var(--danger);padding:10px 14px;border-radius:var(--radius-sm);font-size:13px;margin-bottom:1rem;border-left:3px solid var(--danger)"></div>
              <button type="submit" class="btn btn-primary btn-full" id="regBtn">Create Account</button>
            </form>
            <div class="auth-link" style="margin-top:1rem">Already have an account? <a href="#login">Sign in</a></div>
          </div>
        </div>
      </div>`;
    Toast.init();

    document.querySelectorAll('.toggle-pwd').forEach(btn => {
      btn.addEventListener('click', function() {
        const inp = this.closest('.input-wrap').querySelector('input');
        const isText = inp.type === 'text';
        inp.type = isText ? 'password' : 'text';
        this.querySelector('i').className = isText ? 'ri-eye-line' : 'ri-eye-off-line';
      });
    });

    document.getElementById('registerForm')?.addEventListener('submit', async function(e) {
      e.preventDefault();
      clearFieldErrors(this);
      const btn = document.getElementById('regBtn');
      const errDiv = document.getElementById('regError');
      errDiv.style.display = 'none';
      const fd = new FormData(this);
      const body = Object.fromEntries(fd);
      let valid = true;
      if (!body.first_name) { showFieldError(this.first_name, 'Required.'); valid = false; }
      if (!body.last_name)  { showFieldError(this.last_name,  'Required.'); valid = false; }
      if (!body.email)      { showFieldError(this.email,      'Required.'); valid = false; }
      if (!body.username)   { showFieldError(this.username,   'Required.'); valid = false; }
      if (!body.password || body.password.length < 8) { showFieldError(this.password, 'Min 8 characters.'); valid = false; }
      if (body.password !== body.password_confirm) { showFieldError(this.password_confirm, 'Passwords do not match.'); valid = false; }
      if (!valid) return;
      setLoading(btn, true, 'Creating account…');
      try {
        const data = await API.post('/auth/register/', body);
        Auth.save(data.token, data.user);
        Shell.reset(); Shell.render();
        Router.navigate('dashboard');
        Toast.success('Account created!', 'Welcome to the Student Management System.');
      } catch (err) {
        if (err.data?.errors && typeof err.data.errors === 'object') renderApiErrors(err.data.errors, this);
        else { errDiv.textContent = typeof err.message === 'string' ? err.message : 'Registration failed.'; errDiv.style.display = 'block'; }
        setLoading(btn, false);
      }
    });
  },

  /* ---- Logout confirm ---- */
  confirmLogout() {
    Shell.render();
    const modal = document.createElement('div');
    modal.className = 'modal-overlay show'; modal.id = 'logoutModal';
    modal.innerHTML = `
      <div class="modal modal-sm">
        <div class="modal-header"><span class="modal-title">Confirm Logout</span>
          <button class="modal-close" onclick="document.getElementById('logoutModal').remove()"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:2rem">
          <div class="confirm-icon danger"><i class="ri-logout-circle-r-line"></i></div>
          <h4 style="margin-bottom:0.5rem">Sign out?</h4>
          <p style="color:var(--text-muted);font-size:13.5px">You will be redirected to the login page.</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" onclick="document.getElementById('logoutModal').remove()">Cancel</button>
          <button class="btn btn-danger" id="confirmLogoutBtn">Sign Out</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
    document.getElementById('confirmLogoutBtn')?.addEventListener('click', async () => {
      try { await API.post('/auth/logout/'); } catch {}
      Auth.clear(); Shell.reset();
      window.location.hash = 'login';
      Pages.login();
    });
  },

  /* ---- Dashboard ---- */
  async dashboard() {
    Shell.render(); Shell.setActive('dashboard');
    const content = document.getElementById('pageContent');
    content.innerHTML = `<div style="text-align:center;padding:3rem"><span class="loading-spinner dark"></span></div>`;
    try {
      const [stats, depts] = await Promise.all([
        API.get('/students/dashboard/'),
        API.get('/students/departments/'),
      ]);
      const totalDepts = depts.results?.length || depts.length || 0;
      content.innerHTML = `
        <div class="page-header">
          <h1>Dashboard</h1>
          <p>Welcome back, ${Auth.user?.first_name || 'User'}. Here's a snapshot of the system.</p>
        </div>
        <div class="stats-grid">
          <div class="stat-card"><div class="stat-icon blue"><i class="ri-group-fill"></i></div><div class="stat-info"><div class="stat-value">${stats.total_students}</div><div class="stat-label">Total Students</div></div></div>
          <div class="stat-card"><div class="stat-icon green"><i class="ri-user-follow-fill"></i></div><div class="stat-info"><div class="stat-value">${stats.active_students}</div><div class="stat-label">Active Students</div></div></div>
          <div class="stat-card"><div class="stat-icon orange"><i class="ri-award-fill"></i></div><div class="stat-info"><div class="stat-value">${stats.graduated_students}</div><div class="stat-label">Graduated</div></div></div>
          <div class="stat-card"><div class="stat-icon red"><i class="ri-building-line"></i></div><div class="stat-info"><div class="stat-value">${totalDepts}</div><div class="stat-label">Departments</div></div></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-top:0.5rem">
          <div class="card">
            <div class="card-header"><span class="card-title">Recent Students</span><button class="btn btn-secondary btn-sm" onclick="Router.navigate('students')">View All</button></div>
            <div class="card-body" style="padding:0">
              <table style="width:100%;border-collapse:collapse">
                <thead><tr>
                  <th style="padding:10px 16px;font-size:11px;font-weight:600;color:var(--text-muted);text-align:left;border-bottom:1px solid var(--border)">Student</th>
                  <th style="padding:10px 16px;font-size:11px;font-weight:600;color:var(--text-muted);text-align:left;border-bottom:1px solid var(--border)">Dept</th>
                  <th style="padding:10px 16px;font-size:11px;font-weight:600;color:var(--text-muted);text-align:left;border-bottom:1px solid var(--border)">Status</th>
                </tr></thead>
                <tbody>
                  ${stats.recent_students.map(s => `
                  <tr style="border-bottom:1px solid var(--border)">
                    <td style="padding:10px 16px">
                      <div class="student-name-cell">
                        <div class="table-avatar" style="background:${avatarColor(s.full_name)};width:30px;height:30px;font-size:11px">${initials(s.full_name)}</div>
                        <div><div class="table-name" style="font-size:13px">${s.full_name}</div><div class="table-id">${s.student_id}</div></div>
                      </div>
                    </td>
                    <td style="padding:10px 16px;font-size:13px">${s.department_code}</td>
                    <td style="padding:10px 16px">${statusBadge(s.status)}</td>
                  </tr>`).join('') || '<tr><td colspan="3" style="padding:1.5rem;text-align:center;color:var(--text-muted)">No students yet</td></tr>'}
                </tbody>
              </table>
            </div>
          </div>
          <div class="card">
            <div class="card-header"><span class="card-title">Department Breakdown</span></div>
            <div class="card-body">
              ${(stats.department_breakdown || []).map(d => `
              <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
                <div style="font-size:12px;font-weight:600;color:var(--text-secondary);width:50px;flex-shrink:0">${d.code}</div>
                <div style="flex:1"><div style="font-size:12.5px;color:var(--text-muted);margin-bottom:4px">${d.name}</div>
                  <div style="height:6px;background:var(--border);border-radius:99px;overflow:hidden">
                    <div style="height:100%;background:var(--accent);border-radius:99px;width:${stats.active_students ? Math.round(d.count/stats.active_students*100) : 0}%"></div>
                  </div>
                </div>
                <div style="font-size:13px;font-weight:700;color:var(--text-primary);flex-shrink:0">${d.count}</div>
              </div>`).join('') || '<p style="color:var(--text-muted);font-size:13px">No data yet.</p>'}
            </div>
          </div>
        </div>
        ${Auth.isAdmin() ? `<div class="card" style="margin-top:1.25rem"><div class="card-header"><span class="card-title">Quick Actions</span></div><div class="card-body" style="display:flex;gap:0.75rem;flex-wrap:wrap">
          <button class="btn btn-primary" onclick="Pages.openStudentModal()"><i class="ri-user-add-line"></i>Add Student</button>
          <button class="btn btn-secondary" onclick="Router.navigate('students')"><i class="ri-group-line"></i>Manage Students</button>
          <button class="btn btn-secondary" onclick="Router.navigate('departments')"><i class="ri-building-line"></i>Manage Departments</button>
        </div></div>` : ''}`;
    } catch (err) {
      content.innerHTML = `<div class="empty-state"><div class="empty-state-icon"><i class="ri-wifi-off-line"></i></div><h4>Failed to load dashboard</h4><p>${err.message || 'Please try again.'}</p><button class="btn btn-primary" onclick="Pages.dashboard()">Retry</button></div>`;
    }
  },

  /* ---- Students ---- */
  _studentsState: { page: 1, search: '', dept: '', year: '', status: '', ordering: '-created_at', departments: [] },

  async students() {
    Shell.render(); Shell.setActive('students');
    const content = document.getElementById('pageContent');
    // Load departments for filter
    try {
      const d = await API.get('/students/departments/');
      this._studentsState.departments = d.results || d || [];
    } catch {}
    this._renderStudentsPage(content);
  },

  async _renderStudentsPage(container) {
    const st = this._studentsState;
    const deptOptions = st.departments.map(d => `<option value="${d.id}">${d.name} (${d.code})</option>`).join('');
    container.innerHTML = `
      <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
        <div><h1>Students</h1><p>Manage all student records across departments.</p></div>
        ${Auth.isAdmin() ? `<button class="btn btn-primary" onclick="Pages.openStudentModal()"><i class="ri-user-add-line"></i>Add Student</button>` : ''}
      </div>
      <div class="filter-bar">
        <div class="search-box"><i class="ri-search-line"></i><input type="text" id="searchInput" placeholder="Search by name, ID, email…" value="${st.search}"></div>
        <select class="filter-select" id="deptFilter"><option value="">All Departments</option>${deptOptions}</select>
        <select class="filter-select" id="yearFilter"><option value="">All Years</option>${[1,2,3,4,5].map(y=>`<option value="${y}">Year ${y}</option>`).join('')}</select>
        <select class="filter-select" id="statusFilter"><option value="">All Status</option><option value="active">Active</option><option value="inactive">Inactive</option><option value="graduated">Graduated</option><option value="dropped">Dropped</option></select>
        <button class="btn btn-secondary btn-sm" id="clearFilters"><i class="ri-filter-off-line"></i> Clear</button>
      </div>
      <div id="studentsTableWrap"></div>
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-top:1rem">
        <div class="pagination-info" id="paginationInfo"></div>
        <div class="pagination" id="pagination"></div>
      </div>`;

    // Restore filter values
    document.getElementById('deptFilter').value = st.dept;
    document.getElementById('yearFilter').value = st.year;
    document.getElementById('statusFilter').value = st.status;

    // Events
    let searchTimer;
    document.getElementById('searchInput')?.addEventListener('input', e => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => { st.search = e.target.value; st.page = 1; this._fetchStudents(); }, 350);
    });
    ['deptFilter','yearFilter','statusFilter'].forEach(id => {
      document.getElementById(id)?.addEventListener('change', e => {
        const key = {deptFilter:'dept',yearFilter:'year',statusFilter:'status'}[id];
        st[key] = e.target.value; st.page = 1; this._fetchStudents();
      });
    });
    document.getElementById('clearFilters')?.addEventListener('click', () => {
      st.search=''; st.dept=''; st.year=''; st.status=''; st.page=1;
      document.getElementById('searchInput').value='';
      document.getElementById('deptFilter').value='';
      document.getElementById('yearFilter').value='';
      document.getElementById('statusFilter').value='';
      this._fetchStudents();
    });
    await this._fetchStudents();
  },

  async _fetchStudents() {
    const st = this._studentsState;
    const wrap = document.getElementById('studentsTableWrap');
    if (!wrap) return;
    wrap.innerHTML = `<div style="text-align:center;padding:2rem"><span class="loading-spinner dark"></span></div>`;
    const params = new URLSearchParams({ page: st.page, ordering: st.ordering });
    if (st.search) params.set('search', st.search);
    if (st.dept)   params.set('department', st.dept);
    if (st.year)   params.set('year', st.year);
    if (st.status) params.set('status', st.status);
    try {
      const data = await API.get(`/students/?${params}`);
      const students = data.results || data;
      const count    = data.count || students.length;
      const next     = data.next;
      const prev     = data.previous;
      const totalPages = Math.ceil(count / 10);
      if (!students.length) {
        wrap.innerHTML = `<div class="empty-state"><div class="empty-state-icon"><i class="ri-user-search-line"></i></div><h4>No students found</h4><p>Try adjusting your search or filters.</p></div>`;
        document.getElementById('paginationInfo').textContent = '';
        document.getElementById('pagination').innerHTML = '';
        return;
      }
      wrap.innerHTML = `
        <div class="table-wrap">
          <table>
            <thead><tr>
              <th data-sort="student_id">ID <i class="ri-arrow-up-down-line"></i></th>
              <th data-sort="first_name">Student <i class="ri-arrow-up-down-line"></i></th>
              <th>Department</th>
              <th data-sort="year_of_study">Year</th>
              <th data-sort="cgpa">CGPA <i class="ri-arrow-up-down-line"></i></th>
              <th>Status</th>
              <th>Added</th>
              <th>Actions</th>
            </tr></thead>
            <tbody id="studentsTbody">
              ${students.map(s => this._studentRow(s)).join('')}
            </tbody>
          </table>
        </div>`;
      // Sort click
      wrap.querySelectorAll('th[data-sort]').forEach(th => {
        th.addEventListener('click', () => {
          const f = th.dataset.sort;
          st.ordering = st.ordering === f ? `-${f}` : f;
          this._fetchStudents();
        });
      });
      // Pagination
      document.getElementById('paginationInfo').textContent = `Showing ${(st.page-1)*10+1}–${Math.min(st.page*10,count)} of ${count} students`;
      this._renderPagination(st.page, totalPages);
    } catch (err) {
      wrap.innerHTML = `<div class="empty-state"><div class="empty-state-icon"><i class="ri-error-warning-line"></i></div><h4>Failed to load students</h4><p>${err.message}</p><button class="btn btn-primary btn-sm" onclick="Pages._fetchStudents()">Retry</button></div>`;
    }
  },

  _studentRow(s) {
    const canEdit = Auth.isAdmin();
    return `<tr>
      <td><span style="font-family:var(--font-mono);font-size:12.5px;color:var(--accent)">${s.student_id}</span></td>
      <td><div class="student-name-cell">
        <div class="table-avatar" style="background:${avatarColor(s.full_name)}">${initials(s.full_name)}</div>
        <div><div class="table-name">${s.full_name}</div><div class="table-id">${s.email}</div></div>
      </div></td>
      <td>${s.department_code || '—'}</td>
      <td>Year ${s.year_of_study}</td>
      <td>${s.cgpa || '—'}</td>
      <td>${statusBadge(s.status)}</td>
      <td style="font-size:12px;color:var(--text-muted)">${formatDate(s.created_at)}</td>
      <td>
        <div class="actions-group">
          <button class="btn btn-ghost btn-sm btn-icon-only" title="View" onclick="Pages.viewStudent(${s.id})"><i class="ri-eye-line" style="color:var(--info)"></i></button>
          ${canEdit ? `<button class="btn btn-ghost btn-sm btn-icon-only" title="Edit" onclick="Pages.openStudentModal(${s.id})"><i class="ri-pencil-line" style="color:var(--warning)"></i></button>` : ''}
          ${canEdit ? `<button class="btn btn-ghost btn-sm btn-icon-only" title="Delete" onclick="Pages.deleteStudent(${s.id},'${s.full_name.replace(/'/g,"\\'")}')"><i class="ri-delete-bin-line" style="color:var(--danger)"></i></button>` : ''}
        </div>
      </td>
    </tr>`;
  },

  _renderPagination(current, total) {
    const el = document.getElementById('pagination');
    if (!el || total <= 1) return;
    let html = `<button class="page-btn" ${current===1?'disabled':''} onclick="Pages._studentsState.page=${current-1};Pages._fetchStudents()"><i class="ri-arrow-left-s-line"></i></button>`;
    for (let i = 1; i <= total; i++) {
      if (i===1||i===total||Math.abs(i-current)<=2) html+=`<button class="page-btn ${i===current?'active':''}" onclick="Pages._studentsState.page=${i};Pages._fetchStudents()">${i}</button>`;
      else if (Math.abs(i-current)===3) html+=`<span class="page-btn" style="border:none;cursor:default">…</span>`;
    }
    html+=`<button class="page-btn" ${current===total?'disabled':''} onclick="Pages._studentsState.page=${current+1};Pages._fetchStudents()"><i class="ri-arrow-right-s-line"></i></button>`;
    el.innerHTML = html;
  },

  /* ---- View Student ---- */
  async viewStudent(id) {
    try {
      const data = await API.get(`/students/${id}/`);
      const s = data.data || data;
      const modal = document.createElement('div');
      modal.className = 'modal-overlay show'; modal.id = 'viewStudentModal';
      modal.innerHTML = `
        <div class="modal modal-wide">
          <div class="modal-header">
            <div style="display:flex;align-items:center;gap:12px">
              <div class="table-avatar" style="background:${avatarColor(s.full_name)};width:44px;height:44px;font-size:16px;border-radius:50%">${initials(s.full_name)}</div>
              <div><div class="modal-title">${s.full_name}</div><div style="font-size:12px;color:var(--text-muted)">${s.student_id}</div></div>
            </div>
            <button class="modal-close" onclick="document.getElementById('viewStudentModal').remove()"><i class="ri-close-line"></i></button>
          </div>
          <div class="modal-body">
            <div class="section-title">Academic Information</div>
            <div class="detail-grid" style="margin-bottom:1.5rem">
              <div class="detail-item"><label>Department</label><p>${s.department_name || '—'}</p></div>
              <div class="detail-item"><label>Year of Study</label><p>Year ${s.year_of_study}, Section ${s.section}</p></div>
              <div class="detail-item"><label>CGPA</label><p>${s.cgpa || '—'}</p></div>
              <div class="detail-item"><label>Status</label><p>${statusBadge(s.status)}</p></div>
            </div>
            <div class="section-title">Personal Information</div>
            <div class="detail-grid" style="margin-bottom:1.5rem">
              <div class="detail-item"><label>Email</label><p>${s.email}</p></div>
              <div class="detail-item"><label>Phone</label><p>${s.phone}</p></div>
              <div class="detail-item"><label>Gender</label><p>${s.gender_display || s.gender}</p></div>
              <div class="detail-item"><label>Date of Birth</label><p>${formatDate(s.date_of_birth)}</p></div>
            </div>
            <div class="section-title">Address</div>
            <div class="detail-grid" style="margin-bottom:1.5rem">
              <div class="detail-item"><label>City</label><p>${s.city || '—'}</p></div>
              <div class="detail-item"><label>State</label><p>${s.state || '—'}</p></div>
              <div class="detail-item" style="grid-column:span 2"><label>Address</label><p>${s.address || '—'}</p></div>
            </div>
            <div class="section-title">Record Metadata</div>
            <div class="detail-grid">
              <div class="detail-item"><label>Added On</label><p>${formatDate(s.created_at)}</p></div>
              <div class="detail-item"><label>Last Updated</label><p>${formatDate(s.updated_at)}</p></div>
              <div class="detail-item"><label>Added By</label><p>${s.created_by_name || '—'}</p></div>
            </div>
          </div>
          <div class="modal-footer">
            ${Auth.isAdmin() ? `<button class="btn btn-primary btn-sm" onclick="document.getElementById('viewStudentModal').remove();Pages.openStudentModal(${s.id})"><i class="ri-pencil-line"></i>Edit</button>` : ''}
            <button class="btn btn-secondary" onclick="document.getElementById('viewStudentModal').remove()">Close</button>
          </div>
        </div>`;
      document.body.appendChild(modal);
      modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
    } catch (err) { Toast.error('Error', err.message || 'Could not load student details.'); }
  },

  /* ---- Add / Edit Student Modal ---- */
  async openStudentModal(id = null) {
    let student = null;
    let departments = this._studentsState.departments;
    if (!departments.length) {
      try { const d = await API.get('/students/departments/'); departments = d.results || d; this._studentsState.departments = departments; } catch {}
    }
    if (id) {
      try { const d = await API.get(`/students/${id}/`); student = d.data || d; } catch (err) { Toast.error('Error', err.message); return; }
    }
    const isEdit = !!student;
    const s = student || {};
    const deptOptions = departments.map(d => `<option value="${d.id}" ${s.department==d.id?'selected':''}>${d.name} (${d.code})</option>`).join('');

    const modal = document.createElement('div');
    modal.className = 'modal-overlay show'; modal.id = 'studentModal';
    modal.innerHTML = `
      <div class="modal modal-wide">
        <div class="modal-header">
          <span class="modal-title">${isEdit ? 'Edit Student' : 'Add New Student'}</span>
          <button class="modal-close" onclick="document.getElementById('studentModal').remove()"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
          <form id="studentForm" novalidate>
            <div class="section-title">Identity</div>
            <div class="form-row cols-3" style="margin-bottom:1rem">
              <div class="form-group"><label class="form-label">Student ID <span class="required">*</span></label><input type="text" class="form-input no-icon" name="student_id" value="${s.student_id||''}" placeholder="e.g. 23CSE001" ${isEdit?'readonly':''}><div class="field-error"></div></div>
              <div class="form-group"><label class="form-label">First Name <span class="required">*</span></label><input type="text" class="form-input no-icon" name="first_name" value="${s.first_name||''}" placeholder="First name"><div class="field-error"></div></div>
              <div class="form-group"><label class="form-label">Last Name <span class="required">*</span></label><input type="text" class="form-input no-icon" name="last_name" value="${s.last_name||''}" placeholder="Last name"><div class="field-error"></div></div>
            </div>
            <div class="form-row cols-2" style="margin-bottom:1rem">
              <div class="form-group"><label class="form-label">Email <span class="required">*</span></label><input type="email" class="form-input no-icon" name="email" value="${s.email||''}" placeholder="student@college.edu"><div class="field-error"></div></div>
              <div class="form-group"><label class="form-label">Phone <span class="required">*</span></label><input type="text" class="form-input no-icon" name="phone" value="${s.phone||''}" placeholder="+91 9876543210"><div class="field-error"></div></div>
            </div>
            <div class="form-row cols-2" style="margin-bottom:1rem">
              <div class="form-group"><label class="form-label">Gender <span class="required">*</span></label><select class="form-select" name="gender"><option value="">Select gender</option><option value="M" ${s.gender==='M'?'selected':''}>Male</option><option value="F" ${s.gender==='F'?'selected':''}>Female</option><option value="O" ${s.gender==='O'?'selected':''}>Other</option></select><div class="field-error"></div></div>
              <div class="form-group"><label class="form-label">Date of Birth <span class="required">*</span></label><input type="date" class="form-input no-icon" name="date_of_birth" value="${s.date_of_birth||''}"><div class="field-error"></div></div>
            </div>
            <div class="section-title" style="margin-top:0.5rem">Academic Details</div>
            <div class="form-row cols-2" style="margin-bottom:1rem">
              <div class="form-group"><label class="form-label">Department <span class="required">*</span></label><select class="form-select" name="department"><option value="">Select department</option>${deptOptions}</select><div class="field-error"></div></div>
              <div class="form-group"><label class="form-label">Year of Study <span class="required">*</span></label><select class="form-select" name="year_of_study">${[1,2,3,4,5].map(y=>`<option value="${y}" ${s.year_of_study==y?'selected':''}>Year ${y}</option>`).join('')}</select><div class="field-error"></div></div>
            </div>
            <div class="form-row cols-3" style="margin-bottom:1rem">
              <div class="form-group"><label class="form-label">Section <span class="required">*</span></label><input type="text" class="form-input no-icon" name="section" value="${s.section||''}" placeholder="e.g. A" maxlength="5"><div class="field-error"></div></div>
              <div class="form-group"><label class="form-label">CGPA</label><input type="number" class="form-input no-icon" name="cgpa" value="${s.cgpa||''}" placeholder="0.00–10.00" min="0" max="10" step="0.01"><div class="field-error"></div></div>
              <div class="form-group"><label class="form-label">Status</label><select class="form-select" name="status"><option value="active" ${s.status==='active'||!s.status?'selected':''}>Active</option><option value="inactive" ${s.status==='inactive'?'selected':''}>Inactive</option><option value="graduated" ${s.status==='graduated'?'selected':''}>Graduated</option><option value="dropped" ${s.status==='dropped'?'selected':''}>Dropped</option></select></div>
            </div>
            <div class="section-title" style="margin-top:0.5rem">Address (Optional)</div>
            <div class="form-row cols-2" style="margin-bottom:1rem">
              <div class="form-group"><label class="form-label">City</label><input type="text" class="form-input no-icon" name="city" value="${s.city||''}" placeholder="City"></div>
              <div class="form-group"><label class="form-label">State</label><input type="text" class="form-input no-icon" name="state" value="${s.state||''}" placeholder="State"></div>
            </div>
            <div class="form-group">
              <label class="form-label">Address</label>
              <textarea class="form-textarea" name="address" placeholder="Full address…">${s.address||''}</textarea>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" onclick="document.getElementById('studentModal').remove()">Cancel</button>
          <button class="btn btn-primary" id="saveStudentBtn">${isEdit ? '<i class="ri-save-line"></i> Save Changes' : '<i class="ri-user-add-line"></i> Add Student'}</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });

    document.getElementById('saveStudentBtn')?.addEventListener('click', async () => {
      const form = document.getElementById('studentForm');
      clearFieldErrors(form);
      const fd = new FormData(form);
      const body = {};
      fd.forEach((v, k) => { if (v !== '') body[k] = v; });
      // Required validation
      const required = ['student_id','first_name','last_name','email','phone','gender','date_of_birth','department','year_of_study','section'];
      let valid = true;
      required.forEach(f => { if (!body[f]) { showFieldError(form.querySelector(`[name="${f}"]`), 'This field is required.'); valid = false; } });
      if (!valid) return;
      const btn = document.getElementById('saveStudentBtn');
      setLoading(btn, true, isEdit ? 'Saving…' : 'Adding…');
      try {
        if (isEdit) { await API.patch(`/students/${id}/`, body); Toast.success('Updated!', 'Student record updated.'); }
        else { await API.post('/students/', body); Toast.success('Student added!', `${body.first_name} ${body.last_name} added.`); }
        modal.remove();
        this._fetchStudents();
      } catch (err) {
        if (err.data?.errors) renderApiErrors(err.data.errors, form);
        else Toast.error('Error', typeof err.message === 'string' ? err.message : 'Failed to save.');
        setLoading(btn, false);
      }
    });
  },

  /* ---- Delete Student ---- */
  deleteStudent(id, name) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay show'; modal.id = 'deleteModal';
    modal.innerHTML = `
      <div class="modal modal-sm">
        <div class="modal-header"><span class="modal-title">Delete Student</span><button class="modal-close" onclick="document.getElementById('deleteModal').remove()"><i class="ri-close-line"></i></button></div>
        <div class="modal-body" style="text-align:center;padding:2rem">
          <div class="confirm-icon danger"><i class="ri-delete-bin-fill"></i></div>
          <h4 style="margin-bottom:0.5rem">Delete "${name}"?</h4>
          <p style="color:var(--text-muted);font-size:13.5px">This action cannot be undone. The student record will be permanently removed.</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" onclick="document.getElementById('deleteModal').remove()">Cancel</button>
          <button class="btn btn-danger" id="confirmDeleteBtn"><i class="ri-delete-bin-line"></i> Delete</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
    document.getElementById('confirmDeleteBtn')?.addEventListener('click', async () => {
      const btn = document.getElementById('confirmDeleteBtn');
      setLoading(btn, true, 'Deleting…');
      try {
        const data = await API.delete(`/students/${id}/`);
        Toast.success('Deleted', data.message || 'Student deleted.');
        modal.remove();
        this._fetchStudents();
      } catch (err) {
        Toast.error('Error', err.message || 'Failed to delete.');
        setLoading(btn, false);
      }
    });
  },

  /* ---- Departments ---- */
  async departments() {
    Shell.render(); Shell.setActive('departments');
    const content = document.getElementById('pageContent');
    content.innerHTML = `<div style="text-align:center;padding:3rem"><span class="loading-spinner dark"></span></div>`;
    try {
      const data = await API.get('/students/departments/');
      const depts = data.results || data;
      content.innerHTML = `
        <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
          <div><h1>Departments</h1><p>Manage academic departments.</p></div>
          <button class="btn btn-primary" id="addDeptBtn"><i class="ri-add-line"></i>Add Department</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Department Name</th><th>Code</th><th>Active Students</th><th>Created</th></tr></thead>
            <tbody>${depts.map(d=>`<tr><td><strong>${d.name}</strong></td><td><span style="font-family:var(--font-mono);color:var(--accent)">${d.code}</span></td><td>${d.student_count}</td><td style="color:var(--text-muted);font-size:12px">${formatDate(d.created_at)}</td></tr>`).join('') || '<tr><td colspan="4" style="padding:2rem;text-align:center;color:var(--text-muted)">No departments yet</td></tr>'}
            </tbody>
          </table>
        </div>`;
      document.getElementById('addDeptBtn')?.addEventListener('click', () => this._addDeptModal());
    } catch (err) {
      content.innerHTML = `<div class="empty-state"><div class="empty-state-icon"><i class="ri-error-warning-line"></i></div><h4>Failed to load</h4><p>${err.message}</p></div>`;
    }
  },

  _addDeptModal() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay show'; modal.id = 'deptModal';
    modal.innerHTML = `
      <div class="modal modal-sm">
        <div class="modal-header"><span class="modal-title">Add Department</span><button class="modal-close" onclick="document.getElementById('deptModal').remove()"><i class="ri-close-line"></i></button></div>
        <div class="modal-body">
          <form id="deptForm">
            <div class="form-group"><label class="form-label">Department Name <span class="required">*</span></label><input type="text" class="form-input no-icon" name="name" placeholder="e.g. Computer Science"><div class="field-error"></div></div>
            <div class="form-group"><label class="form-label">Code <span class="required">*</span></label><input type="text" class="form-input no-icon" name="code" placeholder="e.g. CSE" maxlength="10"><div class="field-error"></div></div>
          </form>
        </div>
        <div class="modal-footer"><button class="btn btn-secondary" onclick="document.getElementById('deptModal').remove()">Cancel</button><button class="btn btn-primary" id="saveDeptBtn">Add Department</button></div>
      </div>`;
    document.body.appendChild(modal);
    document.getElementById('saveDeptBtn')?.addEventListener('click', async () => {
      const form = document.getElementById('deptForm');
      clearFieldErrors(form);
      const body = { name: form.name.value.trim(), code: form.code.value.trim().toUpperCase() };
      if (!body.name) { showFieldError(form.name, 'Required.'); return; }
      if (!body.code) { showFieldError(form.code, 'Required.'); return; }
      const btn = document.getElementById('saveDeptBtn');
      setLoading(btn, true);
      try {
        await API.post('/students/departments/', body);
        Toast.success('Department added!', body.name);
        modal.remove(); this.departments();
      } catch (err) {
        if (err.data?.errors) renderApiErrors(err.data.errors, form);
        else Toast.error('Error', err.message);
        setLoading(btn, false);
      }
    });
  },

  /* ---- Profile ---- */
  async profile() {
    Shell.render(); Shell.setActive('profile');
    const content = document.getElementById('pageContent');
    try {
      const user = await API.get('/auth/profile/');
      content.innerHTML = `
        <div class="page-header"><h1>My Profile</h1><p>Manage your account information.</p></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;max-width:860px">
          <div class="card">
            <div class="card-header"><span class="card-title">Account Details</span></div>
            <div class="card-body">
              <div style="text-align:center;margin-bottom:1.5rem">
                <div style="width:80px;height:80px;border-radius:50%;background:${avatarColor(user.full_name)};display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;color:#fff;margin:0 auto 1rem">${initials(user.full_name)}</div>
                <h3>${user.full_name}</h3>
                <div>${user.is_admin ? '<span class="badge badge-admin">Administrator</span>' : '<span class="badge badge-staff">Staff</span>'}</div>
              </div>
              <div class="detail-grid">
                <div class="detail-item"><label>Email</label><p>${user.email}</p></div>
                <div class="detail-item"><label>Username</label><p>${user.username}</p></div>
                <div class="detail-item"><label>Phone</label><p>${user.phone || '—'}</p></div>
                <div class="detail-item"><label>Member Since</label><p>${formatDate(user.created_at)}</p></div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header"><span class="card-title">Change Password</span></div>
            <div class="card-body">
              <form id="pwdForm" novalidate>
                <div class="form-group"><label class="form-label">Current Password <span class="required">*</span></label><input type="password" class="form-input no-icon" name="old_password" placeholder="Enter current password"><div class="field-error"></div></div>
                <div class="form-group"><label class="form-label">New Password <span class="required">*</span></label><input type="password" class="form-input no-icon" name="new_password" placeholder="Minimum 8 characters"><div class="field-error"></div></div>
                <div class="form-group"><label class="form-label">Confirm New Password <span class="required">*</span></label><input type="password" class="form-input no-icon" name="new_password_confirm" placeholder="Repeat new password"><div class="field-error"></div></div>
                <button type="submit" class="btn btn-primary" id="pwdBtn"><i class="ri-lock-password-line"></i> Update Password</button>
              </form>
            </div>
          </div>
        </div>`;
      document.getElementById('pwdForm')?.addEventListener('submit', async function(e) {
        e.preventDefault();
        clearFieldErrors(this);
        const body = { old_password: this.old_password.value, new_password: this.new_password.value, new_password_confirm: this.new_password_confirm.value };
        if (!body.old_password) { showFieldError(this.old_password,'Required.'); return; }
        if (!body.new_password||body.new_password.length<8) { showFieldError(this.new_password,'Minimum 8 characters.'); return; }
        if (body.new_password!==body.new_password_confirm) { showFieldError(this.new_password_confirm,'Passwords do not match.'); return; }
        const btn = document.getElementById('pwdBtn');
        setLoading(btn, true, 'Updating…');
        try {
          const data = await API.post('/auth/change-password/', body);
          Auth.save(data.token, Auth.user);
          Toast.success('Password updated!', 'Your password has been changed.');
          this.reset();
        } catch (err) {
          if (err.data?.errors) renderApiErrors(err.data.errors, this);
          else Toast.error('Error', err.message);
        }
        setLoading(btn, false);
      });
    } catch (err) {
      content.innerHTML = `<div class="empty-state"><h4>Failed to load profile</h4><p>${err.message}</p></div>`;
    }
  },

  /* ---- Users (Admin only) ---- */
  async users() {
    if (!Auth.isAdmin()) { Router.navigate('dashboard'); return; }
    Shell.render(); Shell.setActive('users');
    const content = document.getElementById('pageContent');
    content.innerHTML = `<div style="text-align:center;padding:3rem"><span class="loading-spinner dark"></span></div>`;
    try {
      const data = await API.get('/auth/users/');
      const users = data.results || data;
      content.innerHTML = `
        <div class="page-header"><h1>User Management</h1><p>All registered system users.</p></div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>User</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
            <tbody>${users.map(u=>`<tr>
              <td><div class="student-name-cell"><div class="table-avatar" style="background:${avatarColor(u.full_name||u.email)}">${initials(u.full_name||u.email)}</div><div><div class="table-name">${u.full_name||u.username}</div><div class="table-id">@${u.username}</div></div></div></td>
              <td>${u.email}</td>
              <td>${u.is_admin?'<span class="badge badge-admin">Admin</span>':'<span class="badge badge-staff">Staff</span>'}</td>
              <td style="color:var(--text-muted);font-size:12px">${formatDate(u.created_at)}</td>
            </tr>`).join('')}
            </tbody>
          </table>
        </div>`;
    } catch (err) {
      content.innerHTML = `<div class="empty-state"><h4>Failed to load users</h4><p>${err.message}</p></div>`;
    }
  },

  notFound() {
    Shell.render();
    document.getElementById('pageContent').innerHTML = `
      <div class="empty-state" style="padding:5rem 1rem">
        <div class="empty-state-icon" style="font-size:72px"><i class="ri-compass-3-line"></i></div>
        <h4 style="font-size:24px">Page Not Found</h4>
        <p>The page you're looking for doesn't exist or you don't have permission to view it.</p>
        <button class="btn btn-primary" onclick="Router.navigate('dashboard')">Go to Dashboard</button>
      </div>`;
  },
};

/* ============================================================
   BOOT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  Toast.init();
  Router.register('login',       () => Pages.login());
  Router.register('register',    () => Pages.register());
  Router.register('dashboard',   () => Pages.dashboard());
  Router.register('students',    () => Pages.students());
  Router.register('departments', () => Pages.departments());
  Router.register('profile',     () => Pages.profile());
  Router.register('users',       () => Pages.users());
  Router.init();
});
