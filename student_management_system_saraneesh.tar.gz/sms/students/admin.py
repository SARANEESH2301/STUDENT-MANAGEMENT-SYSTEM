from django.contrib import admin
from .models import Student, Department

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ['name', 'code']
    search_fields = ['name', 'code']

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ['student_id', 'full_name', 'email', 'department', 'year_of_study', 'status', 'created_at']
    list_filter = ['department', 'year_of_study', 'status', 'gender']
    search_fields = ['student_id', 'first_name', 'last_name', 'email']
    readonly_fields = ['created_at', 'updated_at', 'created_by']
