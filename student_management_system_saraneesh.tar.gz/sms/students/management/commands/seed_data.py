from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from students.models import Student, Department
from datetime import date

User = get_user_model()

DEPARTMENTS = [
    ('Computer Science and Engineering', 'CSE'),
    ('Electronics and Communication Engineering', 'ECE'),
    ('Mechanical Engineering', 'MECH'),
    ('Civil Engineering', 'CIVIL'),
    ('Information Technology', 'IT'),
    ('Electrical and Electronics Engineering', 'EEE'),
]

STUDENTS = [
    ('23CSE001', 'Arjun', 'Kumar', 'arjun.kumar@college.edu', '+91 9876543210', 'M', 'CSE', 3, 'A', 8.75, 'active', 'Chennai', 'Tamil Nadu', date(2004, 5, 15)),
    ('23CSE002', 'Priya', 'Sharma', 'priya.sharma@college.edu', '+91 9876543211', 'F', 'CSE', 3, 'A', 9.10, 'active', 'Coimbatore', 'Tamil Nadu', date(2004, 8, 22)),
    ('23ECE001', 'Ravi', 'Krishnan', 'ravi.krishnan@college.edu', '+91 9876543212', 'M', 'ECE', 2, 'B', 7.85, 'active', 'Madurai', 'Tamil Nadu', date(2005, 3, 10)),
    ('22MECH001', 'Ananya', 'Patel', 'ananya.patel@college.edu', '+91 9876543213', 'F', 'MECH', 4, 'A', 8.20, 'active', 'Trichy', 'Tamil Nadu', date(2003, 11, 5)),
    ('21CSE001', 'Vikram', 'Singh', 'vikram.singh@college.edu', '+91 9876543214', 'M', 'CSE', 5, 'C', 7.50, 'graduated', 'Salem', 'Tamil Nadu', date(2002, 7, 18)),
    ('23IT001', 'Deepa', 'Nair', 'deepa.nair@college.edu', '+91 9876543215', 'F', 'IT', 3, 'B', 8.90, 'active', 'Erode', 'Tamil Nadu', date(2004, 2, 28)),
    ('22ECE002', 'Mohammed', 'Ali', 'mohammed.ali@college.edu', '+91 9876543216', 'M', 'ECE', 4, 'A', 6.75, 'active', 'Vellore', 'Tamil Nadu', date(2003, 9, 14)),
    ('23CIVIL001', 'Sneha', 'Reddy', 'sneha.reddy@college.edu', '+91 9876543217', 'F', 'CIVIL', 2, 'A', 8.45, 'active', 'Tirunelveli', 'Tamil Nadu', date(2005, 6, 3)),
    ('22EEE001', 'Karthik', 'Raj', 'karthik.raj@college.edu', '+91 9876543218', 'M', 'EEE', 4, 'B', 7.30, 'inactive', 'Karur', 'Tamil Nadu', date(2003, 4, 20)),
    ('23CSE003', 'Meena', 'Jayaram', 'meena.jayaram@college.edu', '+91 9876543219', 'F', 'CSE', 3, 'B', 9.50, 'active', 'Dindigul', 'Tamil Nadu', date(2004, 12, 1)),
]

class Command(BaseCommand):
    help = 'Seed demo data for the Student Management System'

    def handle(self, *args, **options):
        # Create departments
        dept_map = {}
        for name, code in DEPARTMENTS:
            dept, _ = Department.objects.get_or_create(code=code, defaults={'name': name})
            dept_map[code] = dept
            self.stdout.write(f'  Department: {code}')

        # Create admin user
        admin_user, created = User.objects.get_or_create(
            email='admin@college.edu',
            defaults={
                'username': 'admin',
                'first_name': 'System',
                'last_name': 'Administrator',
                'role': 'admin',
                'is_staff': True,
            }
        )
        if created:
            admin_user.set_password('Admin@1234')
            admin_user.save()
            self.stdout.write('  Admin user created: admin@college.edu / Admin@1234')

        # Create staff user
        staff_user, created = User.objects.get_or_create(
            email='staff@college.edu',
            defaults={
                'username': 'staff',
                'first_name': 'Staff',
                'last_name': 'Member',
                'role': 'staff',
            }
        )
        if created:
            staff_user.set_password('Staff@1234')
            staff_user.save()
            self.stdout.write('  Staff user created: staff@college.edu / Staff@1234')

        # Create students
        for sid, fn, ln, email, phone, gender, dept_code, year, section, cgpa, st, city, state, dob in STUDENTS:
            s, created = Student.objects.get_or_create(
                student_id=sid,
                defaults={
                    'first_name': fn, 'last_name': ln, 'email': email,
                    'phone': phone, 'gender': gender,
                    'department': dept_map[dept_code],
                    'year_of_study': year, 'section': section,
                    'cgpa': cgpa, 'status': st,
                    'city': city, 'state': state,
                    'date_of_birth': dob,
                    'created_by': admin_user,
                }
            )
            if created:
                self.stdout.write(f'  Student: {sid} - {fn} {ln}')

        self.stdout.write(self.style.SUCCESS('\nDemo data seeded successfully!'))
        self.stdout.write('\nLogin credentials:')
        self.stdout.write('  Admin: admin@college.edu / Admin@1234')
        self.stdout.write('  Staff: staff@college.edu / Staff@1234')
