from rest_framework import serializers
from .models import Student, Department

class DepartmentSerializer(serializers.ModelSerializer):
    student_count = serializers.SerializerMethodField()

    class Meta:
        model = Department
        fields = ['id', 'name', 'code', 'student_count', 'created_at']

    def get_student_count(self, obj):
        return obj.students.filter(status='active').count()

class StudentListSerializer(serializers.ModelSerializer):
    department_name = serializers.CharField(source='department.name', read_only=True)
    department_code = serializers.CharField(source='department.code', read_only=True)
    full_name = serializers.SerializerMethodField()
    gender_display = serializers.CharField(source='get_gender_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = Student
        fields = [
            'id', 'student_id', 'full_name', 'first_name', 'last_name',
            'email', 'phone', 'gender', 'gender_display',
            'department', 'department_name', 'department_code',
            'year_of_study', 'section', 'cgpa', 'status', 'status_display',
            'city', 'state', 'created_at', 'updated_at'
        ]

    def get_full_name(self, obj):
        return obj.full_name

class StudentDetailSerializer(serializers.ModelSerializer):
    department_name = serializers.CharField(source='department.name', read_only=True)
    full_name = serializers.SerializerMethodField()
    created_by_name = serializers.SerializerMethodField()

    class Meta:
        model = Student
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by']

    def get_full_name(self, obj):
        return obj.full_name

    def get_created_by_name(self, obj):
        if obj.created_by:
            return obj.created_by.get_full_name()
        return None

    def validate_student_id(self, value):
        value = value.upper().strip()
        instance = self.instance
        qs = Student.objects.filter(student_id=value)
        if instance:
            qs = qs.exclude(pk=instance.pk)
        if qs.exists():
            raise serializers.ValidationError('A student with this ID already exists.')
        return value

    def validate_email(self, value):
        value = value.lower().strip()
        instance = self.instance
        qs = Student.objects.filter(email=value)
        if instance:
            qs = qs.exclude(pk=instance.pk)
        if qs.exists():
            raise serializers.ValidationError('A student with this email already exists.')
        return value
