"""
Student Management System — Test Suite
Author: SARANEESH S
"""
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase, APIClient
from rest_framework import status
from rest_framework.authtoken.models import Token
from .models import Student, Department

User = get_user_model()


# ─────────────────────────── helpers ────────────────────────────────────────

def make_admin(email='admin@test.edu', password='Admin@1234'):
    u = User.objects.create_user(
        email=email, username='admin_test',
        first_name='Test', last_name='Admin',
        password=password, role='admin',
    )
    token, _ = Token.objects.get_or_create(user=u)
    return u, token.key

def make_staff(email='staff@test.edu', password='Staff@1234'):
    u = User.objects.create_user(
        email=email, username='staff_test',
        first_name='Test', last_name='Staff',
        password=password, role='staff',
    )
    token, _ = Token.objects.get_or_create(user=u)
    return u, token.key

def make_dept(name='Computer Science Engineering', code='CSE'):
    return Department.objects.create(name=name, code=code)

def make_student(dept, created_by, **overrides):
    defaults = dict(
        student_id='23CSE001', first_name='Arjun', last_name='Kumar',
        email='arjun@college.edu', phone='+91 9876543210',
        gender='M', date_of_birth='2004-05-15',
        department=dept, year_of_study=3, section='A',
        cgpa='8.75', status='active', created_by=created_by,
    )
    defaults.update(overrides)
    return Student.objects.create(**defaults)


# ─────────────────────────── Authentication ──────────────────────────────────

class AuthTests(APITestCase):

    def setUp(self):
        self.client = APIClient()

    def test_register_success(self):
        payload = {
            'email': 'new@test.edu', 'username': 'newuser',
            'first_name': 'New', 'last_name': 'User',
            'password': 'NewPass@123', 'password_confirm': 'NewPass@123',
        }
        res = self.client.post('/api/auth/register/', payload, format='json')
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        self.assertIn('token', res.data)
        self.assertNotIn('password', res.data.get('user', {}))

    def test_register_password_mismatch(self):
        payload = {
            'email': 'x@test.edu', 'username': 'xuser',
            'first_name': 'X', 'last_name': 'Y',
            'password': 'Pass@1234', 'password_confirm': 'WrongPass',
        }
        res = self.client.post('/api/auth/register/', payload, format='json')
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_register_duplicate_email(self):
        make_admin(email='dup@test.edu')
        payload = {
            'email': 'dup@test.edu', 'username': 'dupuser',
            'first_name': 'Dup', 'last_name': 'User',
            'password': 'Pass@1234', 'password_confirm': 'Pass@1234',
        }
        res = self.client.post('/api/auth/register/', payload, format='json')
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_login_success(self):
        make_admin(email='login@test.edu', password='Admin@1234')
        res = self.client.post('/api/auth/login/', {'email': 'login@test.edu', 'password': 'Admin@1234'}, format='json')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('token', res.data)
        self.assertNotIn('password', res.data)

    def test_login_wrong_password(self):
        make_admin(email='wp@test.edu', password='Admin@1234')
        res = self.client.post('/api/auth/login/', {'email': 'wp@test.edu', 'password': 'wrongpassword'}, format='json')
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)
        # Must not reveal whether account exists — only generic message
        body_str = str(res.data)
        self.assertNotIn('wp@test.edu', body_str)

    def test_login_nonexistent_user(self):
        res = self.client.post('/api/auth/login/', {'email': 'ghost@test.edu', 'password': 'anything'}, format='json')
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_logout_success(self):
        _, token = make_admin()
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {token}')
        res = self.client.post('/api/auth/logout/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)

    def test_logout_unauthenticated(self):
        res = self.client.post('/api/auth/logout/')
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_profile_requires_auth(self):
        res = self.client.get('/api/auth/profile/')
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_profile_returns_no_password(self):
        _, token = make_admin()
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {token}')
        res = self.client.get('/api/auth/profile/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertNotIn('password', res.data)

    def test_change_password_wrong_old(self):
        _, token = make_admin(password='Admin@1234')
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {token}')
        res = self.client.post('/api/auth/change-password/', {
            'old_password': 'WrongOld!', 'new_password': 'NewPass@1234', 'new_password_confirm': 'NewPass@1234',
        }, format='json')
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_change_password_success(self):
        _, token = make_admin(email='cpw@test.edu', password='OldPass@1')
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {token}')
        res = self.client.post('/api/auth/change-password/', {
            'old_password': 'OldPass@1', 'new_password': 'NewPass@2', 'new_password_confirm': 'NewPass@2',
        }, format='json')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('token', res.data)  # new token issued


# ─────────────────────────── CRUD: Students ──────────────────────────────────

class StudentCRUDTests(APITestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin, self.admin_token = make_admin()
        self.staff, self.staff_token = make_staff()
        self.dept = make_dept()
        self.student = make_student(self.dept, self.admin)

    def auth(self, token):
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {token}')

    def _payload(self, **overrides):
        base = {
            'student_id': '23ECE001', 'first_name': 'Ravi', 'last_name': 'K',
            'email': 'ravi.k@college.edu', 'phone': '+91 9001234567',
            'gender': 'M', 'date_of_birth': '2004-01-01',
            'department': self.dept.id, 'year_of_study': 2, 'section': 'B',
        }
        base.update(overrides)
        return base

    # ── READ ─────────────────────────────────────────────────────────────────

    def test_list_requires_auth(self):
        res = self.client.get('/api/students/')
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_list_students_staff(self):
        self.auth(self.staff_token)
        res = self.client.get('/api/students/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)

    def test_list_students_admin(self):
        self.auth(self.admin_token)
        res = self.client.get('/api/students/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(res.data['count'], 1)

    def test_retrieve_student(self):
        self.auth(self.staff_token)
        res = self.client.get(f'/api/students/{self.student.id}/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.data['data']['student_id'], '23CSE001')

    def test_retrieve_nonexistent(self):
        self.auth(self.staff_token)
        res = self.client.get('/api/students/99999/')
        self.assertEqual(res.status_code, status.HTTP_404_NOT_FOUND)

    # ── CREATE ───────────────────────────────────────────────────────────────

    def test_create_student_admin(self):
        self.auth(self.admin_token)
        res = self.client.post('/api/students/', self._payload(), format='json')
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        self.assertIn('message', res.data)

    def test_create_student_staff_forbidden(self):
        self.auth(self.staff_token)
        res = self.client.post('/api/students/', self._payload(), format='json')
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_create_missing_required_fields(self):
        self.auth(self.admin_token)
        res = self.client.post('/api/students/', {'student_id': '23XX001'}, format='json')
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_duplicate_student_id(self):
        self.auth(self.admin_token)
        payload = self._payload(student_id='23CSE001')   # already exists
        res = self.client.post('/api/students/', payload, format='json')
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_duplicate_email(self):
        self.auth(self.admin_token)
        payload = self._payload(email='arjun@college.edu')   # already used
        res = self.client.post('/api/students/', payload, format='json')
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_invalid_cgpa(self):
        self.auth(self.admin_token)
        payload = self._payload(cgpa='11.0')   # > 10
        res = self.client.post('/api/students/', payload, format='json')
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    # ── UPDATE ───────────────────────────────────────────────────────────────

    def test_update_student_admin(self):
        self.auth(self.admin_token)
        res = self.client.patch(f'/api/students/{self.student.id}/', {'cgpa': '9.10'}, format='json')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.student.refresh_from_db()
        self.assertEqual(float(self.student.cgpa), 9.10)

    def test_update_student_staff_forbidden(self):
        self.auth(self.staff_token)
        res = self.client.patch(f'/api/students/{self.student.id}/', {'cgpa': '9.10'}, format='json')
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    # ── DELETE ───────────────────────────────────────────────────────────────

    def test_delete_student_admin(self):
        self.auth(self.admin_token)
        res = self.client.delete(f'/api/students/{self.student.id}/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertFalse(Student.objects.filter(id=self.student.id).exists())

    def test_delete_student_staff_forbidden(self):
        self.auth(self.staff_token)
        res = self.client.delete(f'/api/students/{self.student.id}/')
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_delete_nonexistent(self):
        self.auth(self.admin_token)
        res = self.client.delete('/api/students/99999/')
        self.assertEqual(res.status_code, status.HTTP_404_NOT_FOUND)


# ─────────────────────────── Search & Filter ─────────────────────────────────

class SearchFilterTests(APITestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin, self.token = make_admin()
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.token}')
        self.dept = make_dept()
        self.dept2 = make_dept('Electronics', 'ECE')
        self.s1 = make_student(self.dept,  self.admin, student_id='23CSE001', first_name='Arjun', email='arjun@c.edu')
        self.s2 = make_student(self.dept2, self.admin, student_id='23ECE001', first_name='Priya', email='priya@c.edu', status='graduated')

    def test_search_by_name(self):
        res = self.client.get('/api/students/?search=Arjun')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        names = [s['full_name'] for s in res.data['results']]
        self.assertIn('Arjun Kumar', names)
        self.assertNotIn('Priya Kumar', names)

    def test_search_by_id(self):
        res = self.client.get('/api/students/?search=23ECE001')
        results = res.data['results']
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['student_id'], '23ECE001')

    def test_filter_by_department(self):
        res = self.client.get(f'/api/students/?department={self.dept.id}')
        ids = [s['student_id'] for s in res.data['results']]
        self.assertIn('23CSE001', ids)
        self.assertNotIn('23ECE001', ids)

    def test_filter_by_status(self):
        res = self.client.get('/api/students/?status=graduated')
        statuses = [s['status'] for s in res.data['results']]
        self.assertTrue(all(s == 'graduated' for s in statuses))

    def test_ordering_by_name(self):
        res = self.client.get('/api/students/?ordering=first_name')
        self.assertEqual(res.status_code, status.HTTP_200_OK)


# ─────────────────────────── Dashboard ───────────────────────────────────────

class DashboardTests(APITestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin, self.token = make_admin()
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.token}')
        self.dept = make_dept()
        make_student(self.dept, self.admin)

    def test_dashboard_stats(self):
        res = self.client.get('/api/students/dashboard/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('total_students',   res.data)
        self.assertIn('active_students',  res.data)
        self.assertIn('recent_students',  res.data)
        self.assertGreaterEqual(res.data['total_students'], 1)

    def test_dashboard_unauthenticated(self):
        self.client.credentials()
        res = self.client.get('/api/students/dashboard/')
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)


# ─────────────────────────── Authorization ───────────────────────────────────

class AuthorizationTests(APITestCase):
    """Confirm backend enforcement — cannot bypass by manipulating frontend."""

    def setUp(self):
        self.client = APIClient()
        self.admin, _ = make_admin()
        self.dept = make_dept()
        self.student = make_student(self.dept, self.admin)
        _, self.staff_token = make_staff()
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.staff_token}')

    def test_staff_cannot_create(self):
        res = self.client.post('/api/students/', {
            'student_id': 'NEW001', 'first_name': 'X', 'last_name': 'Y',
            'email': 'xy@c.edu', 'phone': '+919000000000',
            'gender': 'M', 'date_of_birth': '2004-01-01',
            'department': self.dept.id, 'year_of_study': 1, 'section': 'A',
        }, format='json')
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_staff_cannot_update(self):
        res = self.client.patch(f'/api/students/{self.student.id}/', {'cgpa': '10.00'}, format='json')
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_staff_cannot_delete(self):
        res = self.client.delete(f'/api/students/{self.student.id}/')
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_staff_cannot_list_users(self):
        res = self.client.get('/api/auth/users/')
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_unauthenticated_cannot_read(self):
        self.client.credentials()   # remove token
        res = self.client.get('/api/students/')
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)
