from django.urls import path
from .views import StudentListCreateView, StudentDetailView, DepartmentListCreateView, DashboardStatsView

urlpatterns = [
    path('dashboard/', DashboardStatsView.as_view(), name='dashboard-stats'),
    path('', StudentListCreateView.as_view(), name='student-list-create'),
    path('<int:pk>/', StudentDetailView.as_view(), name='student-detail'),
    path('departments/', DepartmentListCreateView.as_view(), name='department-list'),
]
