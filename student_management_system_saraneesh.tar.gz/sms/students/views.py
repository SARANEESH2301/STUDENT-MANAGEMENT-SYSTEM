from rest_framework import status, generics, filters
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db.models import Q, Count
from django.shortcuts import get_object_or_404
from .models import Student, Department
from .serializers import StudentListSerializer, StudentDetailSerializer, DepartmentSerializer
from .permissions import IsAdminUser, IsAdminOrReadOnly

class DashboardStatsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        total = Student.objects.count()
        active = Student.objects.filter(status='active').count()
        graduated = Student.objects.filter(status='graduated').count()
        dept_breakdown = (
            Department.objects.annotate(count=Count('students'))
            .values('name', 'code', 'count')
            .order_by('-count')[:5]
        )
        recent = Student.objects.select_related('department').order_by('-created_at')[:5]
        return Response({
            'total_students': total,
            'active_students': active,
            'graduated_students': graduated,
            'inactive_students': total - active - graduated,
            'department_breakdown': list(dept_breakdown),
            'recent_students': StudentListSerializer(recent, many=True).data,
        })

class StudentListCreateView(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    filter_backends = [filters.OrderingFilter]
    ordering_fields = ['first_name', 'last_name', 'student_id', 'cgpa', 'created_at', 'year_of_study']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return StudentDetailSerializer
        return StudentListSerializer

    def get_queryset(self):
        qs = Student.objects.select_related('department', 'created_by')
        q = self.request.query_params.get('search', '').strip()
        if q:
            qs = qs.filter(
                Q(student_id__icontains=q) |
                Q(first_name__icontains=q) |
                Q(last_name__icontains=q) |
                Q(email__icontains=q) |
                Q(phone__icontains=q) |
                Q(city__icontains=q)
            )
        dept = self.request.query_params.get('department')
        if dept:
            qs = qs.filter(department_id=dept)
        year = self.request.query_params.get('year')
        if year:
            qs = qs.filter(year_of_study=year)
        st = self.request.query_params.get('status')
        if st:
            qs = qs.filter(status=st)
        gender = self.request.query_params.get('gender')
        if gender:
            qs = qs.filter(gender=gender)
        return qs

    def create(self, request, *args, **kwargs):
        if not request.user.is_admin:
            return Response({'errors': 'Only admins can add students.'}, status=status.HTTP_403_FORBIDDEN)
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=request.user)
            return Response({'message': 'Student added successfully.', 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

class StudentDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = StudentDetailSerializer
    queryset = Student.objects.select_related('department', 'created_by')

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        return Response({'data': self.get_serializer(instance).data})

    def update(self, request, *args, **kwargs):
        if not request.user.is_admin:
            return Response({'errors': 'Only admins can edit students.'}, status=status.HTTP_403_FORBIDDEN)
        kwargs['partial'] = True
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Student updated successfully.', 'data': serializer.data})
        return Response({'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        if not request.user.is_admin:
            return Response({'errors': 'Only admins can delete students.'}, status=status.HTTP_403_FORBIDDEN)
        instance = self.get_object()
        name = instance.full_name
        instance.delete()
        return Response({'message': f'Student "{name}" deleted successfully.'})

class DepartmentListCreateView(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated, IsAdminOrReadOnly]
    serializer_class = DepartmentSerializer
    queryset = Department.objects.all()

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Department created.', 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
